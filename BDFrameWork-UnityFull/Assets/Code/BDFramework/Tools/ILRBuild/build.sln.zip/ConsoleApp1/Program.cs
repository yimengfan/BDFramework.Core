﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            if (args.Length >= 2)
            {
                var arg1 = args[0];
                var arg2 = args[1];
                //var arg1 = "E:/Jiyu_work/TheGodClient/TheGod/Assets";
                //var arg2 = "E:/Jiyu_work/TheGodClient/TheGod/Assets/StreamingAssets";
                foreach (var a in args)
                {
                    Console.WriteLine("参数:" + a);
                }
                ScriptBiuld_Service.BuildDLL_DotNet(arg1, arg2);

                Console.ReadLine();
            }
            else
            {
                Console.WriteLine("没有传参");
                Console.ReadLine();
            }
         
        }
    }
}
