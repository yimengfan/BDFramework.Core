﻿namespace BDFramework.DataListener.Hotfix
{
    /// <summary>
    /// 这个是基本数据的服务
    /// </summary>
    public class HF_StatusListenerService : HF_AStatusListener
    {
    }
}