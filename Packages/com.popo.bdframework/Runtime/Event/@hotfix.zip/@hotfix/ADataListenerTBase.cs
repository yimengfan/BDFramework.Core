namespace BDFramework.DataListener.Hotfix
{
    abstract public class ADataListenerTBase
    {
        
    }
}

