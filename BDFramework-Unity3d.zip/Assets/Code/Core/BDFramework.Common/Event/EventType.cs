﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BDFramework.Event
{   
    public enum EventType
    {
        Item = 0,
    }
}
