﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FrameWorkSetting
{
    public int id; 
    public string EditorArtPath;
    public string EditorCodePath;
    public string EditorTablePath;
    public string VersionSettingPath;

}
