﻿using UnityEngine;

namespace BDFramework.UI
{
    public class BMAutoSetValue: MonoBehaviour
    {
        public string name;
    }
}