﻿namespace BDFramework.UI
{
    public enum WinEnum
    {
        Win_Test1 =0,
        Win_Test2 ,
        Win_XVC ,
    }
}