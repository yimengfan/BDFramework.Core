﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIRecord : MonoBehaviour
{
    //需要resize的Transform
    public List<RectTransform> ResizeTransfrom;
}
