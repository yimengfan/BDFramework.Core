﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
/// 做数据驱动服务
/// </summary>
public class DataDrive_Service : ADataDrive
{

}

