﻿namespace Core.BDLogic.LocalDataConfig
{
    public class LocalDataMgr
    {
        
    }
}