﻿namespace BDFramework.Logic.GameLife
{
    public interface IGameStart
    {
        void Start();
        void Awake();
        void Update();
    }
}